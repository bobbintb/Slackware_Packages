config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
config 'etc/slackrepo/slackrepo_msb.conf.new'
config 'etc/slackrepo/slackrepo_csb.conf.new'
config 'etc/slackrepo/slackrepo_SBo.conf.new'
config 'etc/slackrepo/slackrepo_ponce.conf.new'
config 'etc/sudoers.d/slackrepo.new'
( cd usr/bin ; rm -rf slackrepo )
( cd usr/bin ; ln -sf ../sbin/slackrepo slackrepo )
( cd usr/libexec/slackrepo ; rm -rf bash )
( cd usr/libexec/slackrepo ; ln -sf /bin/bash bash )
( cd usr/libexec/slackrepo ; rm -rf chown )
( cd usr/libexec/slackrepo ; ln -sf /bin/chown chown )
( cd usr/libexec/slackrepo ; rm -rf chroot )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/chroot chroot )
( cd usr/libexec/slackrepo ; rm -rf cp )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/cp cp )
( cd usr/libexec/slackrepo ; rm -rf dbus-launch )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/dbus-launch dbus-launch )
( cd usr/libexec/slackrepo ; rm -rf depmod )
( cd usr/libexec/slackrepo ; ln -sf /sbin/depmod depmod )
( cd usr/libexec/slackrepo ; rm -rf explodepkg )
( cd usr/libexec/slackrepo ; ln -sf /sbin/explodepkg explodepkg )
( cd usr/libexec/slackrepo ; rm -rf groupadd )
( cd usr/libexec/slackrepo ; ln -sf /usr/sbin/groupadd groupadd )
( cd usr/libexec/slackrepo ; rm -rf installpkg )
( cd usr/libexec/slackrepo ; ln -sf /sbin/installpkg installpkg )
( cd usr/libexec/slackrepo ; rm -rf kill )
( cd usr/libexec/slackrepo ; ln -sf /bin/kill kill )
( cd usr/libexec/slackrepo ; rm -rf ldconfig )
( cd usr/libexec/slackrepo ; ln -sf /sbin/ldconfig ldconfig )
( cd usr/libexec/slackrepo ; rm -rf mkdir )
( cd usr/libexec/slackrepo ; ln -sf /bin/mkdir mkdir )
( cd usr/libexec/slackrepo ; rm -rf mount )
( cd usr/libexec/slackrepo ; ln -sf /sbin/mount mount )
( cd usr/libexec/slackrepo ; rm -rf mv )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/mv mv )
( cd usr/libexec/slackrepo ; rm -rf pkgtool )
( cd usr/libexec/slackrepo ; ln -sf /sbin/pkgtool pkgtool )
( cd usr/libexec/slackrepo ; rm -rf removepkg )
( cd usr/libexec/slackrepo ; ln -sf /sbin/removepkg removepkg )
( cd usr/libexec/slackrepo ; rm -rf rm )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/rm rm )
( cd usr/libexec/slackrepo ; rm -rf sed )
( cd usr/libexec/slackrepo ; ln -sf /bin/sed sed )
( cd usr/libexec/slackrepo ; rm -rf sh )
( cd usr/libexec/slackrepo ; ln -sf /bin/sh sh )
( cd usr/libexec/slackrepo ; rm -rf slackpkg )
( cd usr/libexec/slackrepo ; ln -sf /usr/sbin/slackpkg slackpkg )
( cd usr/libexec/slackrepo ; rm -rf touch )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/touch touch )
( cd usr/libexec/slackrepo ; rm -rf umount )
( cd usr/libexec/slackrepo ; ln -sf /sbin/umount umount )
( cd usr/libexec/slackrepo ; rm -rf update-gtk-immodules )
( cd usr/libexec/slackrepo ; ln -sf /usr/bin/update-gtk-immodules update-gtk-immodules )
( cd usr/libexec/slackrepo ; rm -rf upgradepkg )
( cd usr/libexec/slackrepo ; ln -sf /sbin/upgradepkg upgradepkg )
( cd usr/libexec/slackrepo ; rm -rf useradd )
( cd usr/libexec/slackrepo ; ln -sf /usr/sbin/useradd useradd )
