config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

config etc/valkey/valkey.conf.new
config etc/valkey/sentinel.conf.new
config etc/logrotate.d/valkey.new
preserve_perms etc/rc.d/rc.valkey.new
( cd usr/bin ; rm -rf redis-benchmark )
( cd usr/bin ; ln -sf valkey-benchmark redis-benchmark )
( cd usr/bin ; rm -rf redis-check-aof )
( cd usr/bin ; ln -sf valkey-check-aof redis-check-aof )
( cd usr/bin ; rm -rf redis-check-rdb )
( cd usr/bin ; ln -sf valkey-check-rdb redis-check-rdb )
( cd usr/bin ; rm -rf redis-cli )
( cd usr/bin ; ln -sf valkey-cli redis-cli )
( cd usr/bin ; rm -rf redis-sentinel )
( cd usr/bin ; ln -sf valkey-sentinel redis-sentinel )
( cd usr/bin ; rm -rf redis-server )
( cd usr/bin ; ln -sf valkey-server redis-server )
( cd usr/bin ; rm -rf valkey-check-aof )
( cd usr/bin ; ln -sf valkey-server valkey-check-aof )
( cd usr/bin ; rm -rf valkey-check-rdb )
( cd usr/bin ; ln -sf valkey-server valkey-check-rdb )
( cd usr/bin ; rm -rf valkey-sentinel )
( cd usr/bin ; ln -sf valkey-server valkey-sentinel )
