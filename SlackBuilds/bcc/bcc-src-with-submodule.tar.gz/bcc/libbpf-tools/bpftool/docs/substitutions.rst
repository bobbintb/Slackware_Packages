.. SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)

.. |COMMON_OPTIONS| replace:: { **-j** | **--json** } [{ **-p** | **--pretty** }] | { **-d** | **--debug** } | { **-l** | **--legacy** }
